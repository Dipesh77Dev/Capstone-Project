import './App.css';
import Home from "./components/Home.js";
import { Whole } from "./components/Whole.js";
function App() {
  return (
    <>
    {/* <h1> Hello World </h1> */}
    {/* < Home /> */}
    < Whole />
    </>
  );
}

export default App;
