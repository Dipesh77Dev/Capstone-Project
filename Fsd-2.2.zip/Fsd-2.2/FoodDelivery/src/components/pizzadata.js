const pizzas=[
    {
        name: "PEPPER BARRBEQUE CHICKEN",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 200,
                "medium": 350,
                "large": 400
            }
        ],
        category: "nonveg",
        image: "https://www.dominos.co.in//files/items/Pepper_Barbeque.jpg",
        description: "pepper Barbeque Chichen Cheeze"
    },

    {
        name: "GOLDEN CORN PIZZA",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 100,
                "medium": 150,
                "large": 200
            }
        ],
        category: "veg",
        image: "https://www.dominos.co.in//files/items/golden_corn_veg.jpg",
        description: "Golden Corn Pizza with Cheese Slice"
    },

    {
        name: "NON VEG SUPREME",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 130,
                "medium": 250,
                "large": 300
            }
        ],
        category: "nonveg",
        image: "https://www.dominos.co.in//files/items/Non-Veg_Supreme.jpg",
        description: "Non veg supreme with slices of chicken"
    },

    {
        name: "MARGARITA",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 220,
                "medium": 300,
                "large": 360
            }
        ],
        category: "nonveg",
        image: "https://www.dominos.co.in//files/items/Margherit.jpg",
        description: "Margarita with small pieces of cheese"
    },

    {
        name: "PEPPY PANEER",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 100,
                "medium": 250,
                "large": 300
            }
        ],
        category: "nonveg",
        image: "https://www.dominos.co.in//files/items/Peppy_Paneer.jpg",
        description: "Peppy paneer with mouthful of margarita"
    },

    {
        name: "INDI CHICKEN TIKKA",
        varients: [
            "small",
            "medium",
            "large"
        ],
        prices: [
            {
                "small": 300,
                "medium": 450,
                "large": 500
            }
        ],
        category: "nonveg",
        image: "https://www.dominos.co.in//files/items/IndianChickenTikka.jpg",
        description: "Indi Chicken tikka with small pieces of chicken"
    }
]

export default pizzas;